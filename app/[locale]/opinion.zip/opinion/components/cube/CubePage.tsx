"use client";

import { useEffect, useState } from "react";

import "./cube.scss";

import FrontIntroduction from "./FrontIntroduction/FrontIntroduction";
import BackReveal from "./BackReveal/BackReveal";
import LeftPessimism from "./LeftPessimism/LeftPessimism";
import RightOptimism from "./RightOptimism/RightOptimism";
import TopConclusion from "./TopConclusion/TopConclusion";
import BottomChoice from "./BottomChoice/BottomChoice";

type Screen =
  | "front"
  | "bottom"
  | "left"
  | "right"
  | "back"
  | "top";

export default function CubePage() {
  const [rotation, setRotation] = useState({
    x: 90,
    y: 0,
  });

  const [screen, setScreen] = useState<Screen>("bottom");

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const key = e.key.toLowerCase();

      setRotation((r) => {
        switch (key) {
          case "w":
            switch (screen) {
              case "back":
                setScreen("bottom");
                return { x: r.x + 90, y: r.y };

              case "top":
                setScreen("back");
                return { x: r.x + 90, y: r.y };

              default:
                return r;
            }

          case "s":
            switch (screen) {
              case "front":
                setScreen("bottom");
                return { x: r.x - 90, y: r.y };

              case "bottom":
                setScreen("back");
                return { x: r.x - 90, y: r.y };

              case "back":
                setScreen("top");
                return { x: r.x - 90, y: r.y };

              default:
                return r;
            }

          case "a":
            switch (screen) {
              case "bottom":
                setScreen("left");
                return { x: r.x, y: r.y - 90 };

              case "right":
                setScreen("bottom");
                return { x: r.x, y: r.y - 90 };

              default:
                return r;
            }

          case "d":
            switch (screen) {
              case "bottom":
                setScreen("right");
                return { x: r.x, y: r.y + 90 };

              case "left":
                setScreen("bottom");
                return { x: r.x, y: r.y + 90 };

              default:
                return r;
            }

          default:
            return r;
        }
      });
    }

    window.addEventListener("keydown", onKey);

    return () => window.removeEventListener("keydown", onKey);
  }, [screen]);

  return (
    <main className="scene">
      <div
        className="world"
        style={{
          transform: `
            translate(-50%, -50%)
            rotateX(${rotation.x}deg)
            rotateY(${rotation.y}deg)
          `,
        }}
      >
        <FrontIntroduction />
        <BackReveal />
        <LeftPessimism />
        <RightOptimism />
        <BottomChoice />
        <TopConclusion />
      </div>
    </main>
  );
}